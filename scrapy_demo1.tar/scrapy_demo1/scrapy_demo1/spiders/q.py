# -*- coding: utf-8 -*-
import scrapy
from scrapy_demo1.items import ScrapyDeom1Item
from scrapy.http.cookies import CookieJar
from scrapy.http import Request
# from urllib.parse import urlencode  # 可将字典格式 {x:x,xxx:xxx} 转换为 x=x&xxx=xxx&...


# 爬取 chouti.com 的文章
class QSpider(scrapy.Spider):
    name = 'q'
    allowed_domains = ['chouti.com']
    start_urls = ['http://chouti.com/']

    def parse(self, response):
        item_list = response.xpath('//div[@id="content-list"]/div[@class="item"]')

        for item in item_list:
            href = item.xpath('.//a/@href').extract_first()
            txt = item.xpath('.//a/text()').extract_first()
            yield ScrapyDeom1Item(text=txt, href=href)

        page_list = response.xpath('//div[@id="dig_lcpage"]//a/@href').extract()
        # page_list = response.xpath('//div[@id="dig_lcpage"]//a/@href').extract_first()
        from scrapy.http import Request
        for page in page_list:
            page = 'https://dig.chouti.com' + page
            # 为每一个 URL 实例化，并且给其对应得 callback 标识
            yield Request(url=page, callback=self.parse, dont_filter=False)   # 标识遵循去重规则
            # yield Request(url=page, callback=self.parse, dont_filter=True)  # 标识不遵循去重规则


# 一键点赞
class QSpider(scrapy.Spider):
    name = 'q'
    allowed_domains = ['chouti.com']
    start_urls = ['http://chouti.com/']
    cookie_dict = {}    # 存放 cookie 的字典
    def parse(self, response):
        # 去响应头中获取cookie，cookie保存在cookie_jar对象
        cookie_jar = CookieJar()
        cookie_jar.extract_cookies(response, response.request)

        # 去对象中将cookie解析到字典
        for k, v in cookie_jar._cookies.items():
            for i, j in v.items():
                for m, n in j.items():
                    self.cookie_dict[m] = n.value

        yield Request(
            url='https://dig.chouti.com/login',
            method='POST',
            body="phone=86手机号&password=账号密码&oneMonth=1",
            # # body=urlencode({})"phone=8615131255555&password=12sdf32sdf&oneMonth=1"
            cookies=self.cookie_dict,
            headers={
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            callback=self.check_login
        )

    def check_login(self, response):
        print(response.text)

        yield Request(
            url='https://dig.chouti.com/all/hot/recent/1',
            cookies=self.cookie_dict,
            callback=self.index
        )

    def index(self, response):
        """
        获取到所有文章id, 并发送一个点赞请
        :param response:
        :return:
        """
        news_list = response.xpath('//div[@id="content-list"]/div[@class="item"]')
        for new in news_list:
            link_id = new.xpath('.//div[@class="part2"]/@share-linkid').extract_first()
            yield Request(
                url='http://dig.chouti.com/link/vote?linksId=%s' % (link_id,),
                method='POST',
                cookies=self.cookie_dict,
                callback=self.check_result
            )

        page_list = response.xpath('//div[@id="dig_lcpage"]//a/@href').extract()
        for page in page_list:
            page = "https://dig.chouti.com" + page
            yield Request(url=page, callback=self.index)  # https://dig.chouti.com/all/hot/recent/2

    def check_result(self, response):
        print(response.text)
