# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

from scrapy.exceptions import DropItem


class FilePipeline(object):

    def __init__(self, path):
        self.f = None
        self.path = path

    @classmethod
    def from_crawler(cls, crawler):
        """
        初始化的时候，用来创建 pipeline 对象
        :param crawler:
        :return:
        """
        # 去settings 寻找要保存的文件路径
        path = crawler.settings.get('FILE_PATH')
        return cls(path)

    def open_spider(self, spider):
        """
        爬虫刚启动时调用 - 此处用来做打开文件操作
        :param spider:
        :return:
        """
        self.f = open(self.path, 'a+')

    def process_item(self, item, spider):
        """
        爬虫执行中调用 - 此处用来做将数据写入文件操作
        :param item:
        :param spider:
        :return:
        """
        print('***')
        txt = item['text'].strip()
        self.f.write(txt+'\n')
        # self.f.write(item['href']+'\n')
        return item
        # raise DropItem  # 使后续的 pipeline 的 process_item 方法不执行

    def close_spider(self, spider):
        """
        爬虫执行完毕后调用 - 此处用来做关闭文件操作
        :param spider:
        :return:
        """
        self.f.close()


class DBPipeline(object):

    def __init__(self, path):
        self.f = None
        self.path = path

    @classmethod
    def from_crawler(cls, crawler):
        """
        初始化的时候，用来创建 pipline 对象
        :param crawler:
        :return:
        """
        # 去settings 寻找要保存的文件路径
        path = crawler.settings.get('DB_PATH')
        return cls(path)

    def open_spider(self, spider):
        """
        爬虫刚启动时调用 - 此处用来做打开文件操作
        :param spider:
        :return:
        """
        self.f = open(self.path, 'a+')

    def process_item(self, item, spider):
        """
        爬虫执行中调用 - 此处用来做将数据写入文件操作
        :param item:
        :param spider:
        :return:
        """

        # self.f.write(item['href']+'\n')
        return item

    def close_spider(self, spider):
        """
        爬虫执行完毕后调用 - 此处用来做关闭文件操作
        :param spider:
        :return:
        """
        self.f.close()