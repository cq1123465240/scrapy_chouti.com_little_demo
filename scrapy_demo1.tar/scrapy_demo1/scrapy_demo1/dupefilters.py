# -*- coding: utf-8 -*-

from scrapy.dupefilters import BaseDupeFilter
from scrapy.utils.request import request_fingerprint


class MyDupeFilter(BaseDupeFilter):

    def __init__(self):
        self.visited_fd = set()

    @classmethod
    def from_settings(cls, settings):
        return cls()

    def request_seen(self, request):
        """
        判断当前请求的URL是否存在 - 用于去重
            - 如果存在则  pass
            - 如不存在则  添加
        :param request:
        :return:
        """
        print(request)
        # 将当前 URL 加密成一定位数的字符
        fd = request_fingerprint(request=request)
        if fd in self.visited_fd:
            return True
        self.visited_fd.add(fd)

    def open(self):  # can return deferred
        """
        执行前的一些操作
        :return:
        """
        print('爬虫开始')

    def close(self, reason):  # can return a deferred
        """
        执行结束后的一些操作
        :param reason:
        :return:
        """
        print('爬虫结束')

    def log(self, request, spider):  # log that a request has been filtered
        """
        访问的每一个  URL  的日志信息
        :param request:
        :param spider:
        :return:
        """
        pass
